import { Component } from '@angular/core';
import { CodegenComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'Realtime Text Editor';

  codeEditorFlag = false;
  textEditorFlag = false;

  toggleTextEditor():void {
    this.textEditorFlag = !this.textEditorFlag;
  }

  toggleCodeEditor(): void {
    this.codeEditorFlag = !this.codeEditorFlag;
  }
}
