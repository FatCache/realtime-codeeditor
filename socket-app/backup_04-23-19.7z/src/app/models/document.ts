export class Document {
    id: string;
    doc: string;
}
