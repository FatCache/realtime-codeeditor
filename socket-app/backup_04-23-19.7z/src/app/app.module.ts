import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io'
import { NgModule } from '@angular/core';
import { Ng5SliderModule } from 'ng5-slider';

import { AppComponent } from './app.component';
import { DocumentListComponent } from './document-list/document-list.component';
import { DocumentComponent } from './document/document.component';
import { CodeeditorComponent } from './codeeditor/codeeditor.component';
import { DocumentService } from './services/document.service';
import { CodeeditorService } from './services/codeeditor.service';

const config: SocketIoConfig = { url: 'http://localhost:4444', options: {} };


import { AceEditorModule } from 'ng2-ace-editor';

@NgModule({
  declarations: [
    AppComponent,
    DocumentListComponent,
    DocumentComponent,
    CodeeditorComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    SocketIoModule.forRoot(config),
    AceEditorModule,
    Ng5SliderModule,
    ReactiveFormsModule
  ],
  providers: [DocumentService, CodeeditorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
