const app = require('express')();
const http = require('http').Server(app);
// Provides aditional abstract layer over web sockets
const io = require('socket.io')(http);

// config variables
verbose = true ;
session_directory = "/tmp" ;

var fs = require( "fs" ) ;

// In memory database
const documents = {}

const deltasHistory = [];

io.on("connection", socket => {
     console.log("Connected > socket");

    let previousId;

    const safeJoin = currentId => {
      socket.leave(previousId);
      socket.join(currentId);
      previousId = currentId;
    };

    console.log("Room Called:" + previousId);
    
    // On document retrival
    socket.on("getDoc", docId => {
      safeJoin(docId);
      socket.emit("document", documents[docId]);
    });
  
    // Initilaize the Keys
    io.emit("documents", Object.keys(documents));

    // On Document creation
    socket.on("addDoc", doc => {
      documents[doc.id] = doc;
      safeJoin(doc.id);
      io.emit("documents", Object.keys(documents));
      socket.emit("document", doc);
    });
  
    // On document's text change
    socket.on("editDoc", doc => {
      documents[doc.id] = doc;
      socket.to(doc.id).emit("document", doc);
    });


    // #### Code Document Service ####

    // Initiliaze history of changes
    socket.emit("deltasHistory",deltasHistory);

    socket.on("deltasHistory", r =>{
      socket.emit("deltasHistory",deltasHistory);
    })
    
    socket.on("updateCodeDocument", delta => {
      socket.broadcast.emit("currentCode",delta);
    
      // Update the history of deltas
      deltasHistory.push(delta);
    })

    //Clear all changes
    socket.on("clearHistory", e =>{
      deltasHistory.length = 0;
      console.log(deltasHistory)
      socket.emit("deltasHistory",deltasHistory);
    })
    
    
  }),
  
http.listen(4444)
